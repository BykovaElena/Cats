
const popupCats = document.querySelector('.popup-type-cats-info');
const popupCatImage = popupCats.querySelector('.popup-photo');
const popupCatText = popupCats.querySelector('.popup-text');
const popupCatDescription = popupCats.querySelector('.popup-description');
const popupCatAge = popupCats.querySelector('.popup-age');
const catImages = document.querySelectorAll('.cat-photo');
const closePopupCats = document.querySelector('.popup-close');
const cardTemplate = document.querySelector('#card-template');
const cardListContainer = document.querySelector('.cats-list');








function openPopup (popup){
    popup.classList.add ('popup-opened');
}
function closePopup (){
    const popupActive = document.querySelector('.popup-opened')
   if (popupActive) { 
       popupActive.classList.remove ('popup-opened');
 }
} 



function handleClosePopup(){
    closePopup(popupCats) 
   }

   



   function createCardCat (dataCat){
     const newCardElement =  cardTemplate.content.querySelector('.cat-list-item-cat').cloneNode(true);
      
       
     const cardImage = newCardElement.querySelector('.cat-photo');
     const cardName = newCardElement.querySelector('.cat-name');
    const catRate = newCardElement.querySelector('.rate');

     
     
     cardImage.src = dataCat.img_link;
     cardName.textContent = dataCat.name;
     catRate.textContent = dataCat.rate;
     
     

     function handleClickCatImage(){
        popupCatImage.src = dataCat.img_link;
        popupCatText.textContent = dataCat.name;

        popupCatAge.textContent = dataCat.age;
        
        if (+dataCat.age >=11&& +dataCat.age <=20){
            popupCatAge.textContent +=' лет' 
        }else if (+dataCat.age ==1) {
            popupCatAge.textContent +=' год'
        }else if (+dataCat.age >=2 && +dataCat.age<=4){
            popupCatAge.textContent +=' года'
        }else if(+dataCat.age >=5 && +dataCat.age<=9){
            popupCatAge.textContent +=' лет'
        }

        popupCatDescription.textContent = dataCat.description;

        openPopup(popupCats) 
    }
     
    
     cardImage.addEventListener('click', handleClickCatImage)
return newCardElement;

   }

   function cardAddToContainer(elementNode, container){
       container.append(elementNode)

   }
   cats.forEach(dataCat => cardAddToContainer (createCardCat(dataCat),cardListContainer))

 
   

closePopupCats.addEventListener('click', closePopup);





